import java.util.Random;
import java.util.Scanner;

public class NumbersGen {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        boolean playAgain = true;

        System.out.println("🎯 Welcome to the Number Guessing Game!");
        System.out.println("---------------------------------------");

        while (playAgain) {
            int numberToGuess = random.nextInt(100) + 1; // Random number 1-100
            int attempts = 0;
            int maxAttempts = 5;
            boolean hasGuessed = false;

            System.out.println("\nI have chosen a number between 1 and 100.");
            System.out.println("You have " + maxAttempts + " attempts to guess it.");

            while (attempts < maxAttempts) {
                System.out.print("\n👉 Enter your guess: ");
                int guess = sc.nextInt();
                attempts++;

                if (guess == numberToGuess) {
                    System.out.println("✅ Correct! You guessed it in " + attempts + " attempts.");
                    hasGuessed = true;
                    break;
                } 
                // Check if close (within 5 numbers)
                else if (Math.abs(guess - numberToGuess) <= 5) {
                    System.out.println("🔥 You're very close! Try again.");
                } 
                else if (guess < numberToGuess) {
                    System.out.println("📉 Too low! Try again.");
                } 
                else {
                    System.out.println("📈 Too high! Try again.");
                }
            }

            if (!hasGuessed) {
                System.out.println("\n❌ You ran out of attempts! The number was: " + numberToGuess);
            }

            System.out.print("\n🔄 Do you want to play again? (yes/no): ");
            String response = sc.next().toLowerCase();
            playAgain = response.equals("yes");
        }

        System.out.println("\n👋 Thanks for playing! See you next time.");
        System.out.println("---------------------------------------");
        sc.close();
    }
}
